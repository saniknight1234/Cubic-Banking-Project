package com.rab3tech.customer.dao.repository;

import java.util.Optional;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rab3tech.dao.entity.PayeeInfo;



public interface PayeeInfoRepository extends JpaRepository<PayeeInfo, Integer>{
	Optional<PayeeInfo> findByCustomerIdAndPayeeAccountNo(String custId, String accNo);
	List<PayeeInfo> findByCustomerId(String custId);

}
