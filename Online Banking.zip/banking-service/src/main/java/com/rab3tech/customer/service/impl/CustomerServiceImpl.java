package com.rab3tech.customer.service.impl;


import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rab3tech.admin.dao.repository.CustomerSecurityQuestionsRepository;
import com.rab3tech.admin.dao.repository.MagicCustomerRepository;
import com.rab3tech.customer.dao.repository.CustomerQuestionsAnsRepository;
import com.rab3tech.customer.dao.repository.RoleRepository;
import com.rab3tech.customer.service.CustomerService;
import com.rab3tech.dao.entity.Customer;
import com.rab3tech.dao.entity.CustomerQuestionAnswer;
import com.rab3tech.dao.entity.Login;
import com.rab3tech.dao.entity.Role;
import com.rab3tech.utils.PasswordGenerator;
import com.rab3tech.vo.CustomerVO;

import java.util.List;

@Service
@Transactional
public class CustomerServiceImpl implements  CustomerService{
	
	@Autowired
	private MagicCustomerRepository customerRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private CustomerQuestionsAnsRepository customerQuestionsAnsRepository;
	
	
	@Override
	public CustomerVO createAccount(CustomerVO customerVO) {
		Customer pcustomer = new Customer();
		BeanUtils.copyProperties(customerVO, pcustomer);
		Login login = new Login();
		login.setNoOfAttempt(3);
		login.setLoginid(customerVO.getEmail());
		login.setName(customerVO.getName());
		String genPassword=PasswordGenerator.generateRandomPassword(8);
		customerVO.setPassword(genPassword);
		login.setPassword(bCryptPasswordEncoder.encode(genPassword));
		login.setToken(customerVO.getToken());
		login.setLocked("no");
		
		Role entity=roleRepository.findById(3).get();
		Set<Role> roles=new HashSet<>();
		roles.add(entity);
		//setting roles inside login
		login.setRoles(roles);
		//setting login inside
		pcustomer.setLogin(login);
		Customer dcustomer=customerRepository.save(pcustomer);
		customerVO.setId(dcustomer.getId());
		customerVO.setUserid(customerVO.getUserid());
		return customerVO;
	}


	@Override
	public CustomerVO getCustomerData(String email) {
		CustomerVO vo = new CustomerVO();
		Optional<Customer> customer = customerRepository.findByEmail(email);
		BeanUtils.copyProperties(customer.get(), vo);
		
		//Getting Question and Answer data and setting it to VO
		List<CustomerQuestionAnswer> customerQuestionAnswers = customerQuestionsAnsRepository.findQuestionAnswer(email);
		vo.setQuestion1(customerQuestionAnswers.get(0).getQuestion());
		vo.setAnswer1(customerQuestionAnswers.get(0).getAnswer());
		vo.setQuestion2(customerQuestionAnswers.get(1).getQuestion());
		vo.setAnswer2(customerQuestionAnswers.get(1).getAnswer());
		
		
		
		return vo;
	}


	@Override
	public String updateProfile(CustomerVO customerVO) {
		//Customer customerEntity = new Customer();
		//Getting everything from the data base
		Customer customerEntity = customerRepository.findByEmail(customerVO.getEmail()).get();
		
		//he we are using BeanUtils.copyProperties ignore option for fields that
		// we don't want change. therefore we need create a string arrays of fields that we want to ignore
		String[] ignoreProp = {"photoName", "email", "login"};
		BeanUtils.copyProperties(customerVO, customerEntity, ignoreProp);
		
		//set the date of modification when we modify some fields
		customerEntity.setDom(new Timestamp(new Date().getTime()));
		 //save all new data to the database 
		//customerRepository.save(customerEntity);
		
		//Question and Answer Update..
		//putting Question and Answers and a List
		List<CustomerQuestionAnswer> customerQuestionAnswers = customerQuestionsAnsRepository.findQuestionAnswer(customerVO.getEmail());
		//get the first question
		CustomerQuestionAnswer q1 = customerQuestionAnswers.get(0);
		//setting or changing answer1 or getting the answer from user interface and setting into the database.
		q1.setAnswer(customerVO.getAnswer1());
		//customerQuestionsAnsRepository.save(q1);
		q1.setDom(new Timestamp(new Date().getTime()));
		
		
		CustomerQuestionAnswer q2 = customerQuestionAnswers.get(1);
		//setting or changing answer2
		q2.setAnswer(customerVO.getAnswer2());
		q2.setDom(new Timestamp(new Date().getTime()));
		
		//customerQuestionsAnsRepository.save(q2);
		return "Profile Updated";
	}
	/*
	 * @Override public String updateProfile(CustomerVO customerVO) { //Customer
	 * customerEntity = new Customer(); Customer customerEntity =
	 * customerRepository.findById(customerVO.getId()).get();
	 *now we change the fields that we want to change in the data base or update the fields
	 *want to change name
	 * customerEntity.setName(customerVO.getName());
	 * change email
	 * customerEntity.setEmail(customerVO.getEmail());
	 * BeanUtils.copyProperties(customerVO, customerEntity);
	 * set the date of modification when we modify some fields
	 * customerEntity.setDom(new Timestamp(new Date().getTime());
	 * customerRepository.save(customerEntity); return "Profile Updated"; }
	 */

}
