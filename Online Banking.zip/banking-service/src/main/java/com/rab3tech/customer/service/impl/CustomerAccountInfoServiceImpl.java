package com.rab3tech.customer.service.impl;

import java.util.Date;
import java.util.Optional;

import javax.persistence.FetchType;
import javax.persistence.OneToOne;
import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rab3tech.customer.dao.repository.CustomerAccountEnquiryRepository;
import com.rab3tech.customer.dao.repository.CustomerAccountInfoRepository;
import com.rab3tech.customer.service.CustomerAccountInfoService;
import com.rab3tech.dao.entity.CustomerAccountInfo;
import com.rab3tech.dao.entity.CustomerSaving;
import com.rab3tech.vo.CustomerAccountInfoVO;

@Service
@Transactional
public class CustomerAccountInfoServiceImpl implements CustomerAccountInfoService {

	@Autowired
	CustomerAccountInfoRepository accountInfoRepository;
	@Autowired
	CustomerAccountEnquiryRepository savingAccountEnquiryRepository;// abdul COde

	@Override
	public CustomerAccountInfoVO createAccount(String loginId) {
		// checking if the account exist or not
		Optional<CustomerAccountInfo> customerAccount = accountInfoRepository.findByCustomerId(loginId);
		CustomerAccountInfo account = new CustomerAccountInfo();
		CustomerAccountInfoVO vo = new CustomerAccountInfoVO();

		if (customerAccount.isPresent()) {
			account = customerAccount.get();
			vo.setMessage("You alread have an existing account, below are the details..");
			
		} else {
			CustomerAccountInfo accountEntity = new CustomerAccountInfo();
			// Set the Entire entity
			accountEntity.setCustomerId(loginId);

			accountEntity.setCurrency("USD");

			accountEntity.setTavBalance(1000);
			accountEntity.setAvBalance(1000);
			accountEntity.setStatusAsOf(new Date());
			// calling customer saving tbl and geting below information
			CustomerSaving cutomerSaving = savingAccountEnquiryRepository.findByEmail(loginId).get();

			accountEntity.setBranch(cutomerSaving.getLocation());
			accountEntity.setAccountNumber(cutomerSaving.getAppref());// @OneToOne(fetch = FetchType.EAGER)
			accountEntity.setAccountType(cutomerSaving.getAccType().getName());// TBD

			account = accountInfoRepository.save(accountEntity);
			vo.setMessage("Your new account has been created. Congrats!! ");

			
		}

		
		BeanUtils.copyProperties(account, vo);

		return vo;
	}

}
