package com.rab3tech.customer.service;

import com.rab3tech.vo.CustomerAccountInfoVO;

public interface CustomerAccountInfoService {
	public CustomerAccountInfoVO createAccount(String loginId);

}
