package com.rab3tech;

public class MathService {

	public int magic(int num1,int num2) {
		  //assuming it is accessing database
		  int result=10+num1+num2;
		  return result;
	}
}
